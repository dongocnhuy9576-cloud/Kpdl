import math

pi = math.pi
r = float(input("Moi ban nhap ban kinh: "))
cv = 2*pi*r
dt = pi*pow(r, 3)
print("Chu vi: %f" %cv)
print("Dien tich: %f" %dt)